﻿namespace eAppointment.Backend.Domain.Enums
{
    public enum FilterMatchMode
    {
        Contains,
        StartsWith,
        EndsWith,
        Equals
    }
}
