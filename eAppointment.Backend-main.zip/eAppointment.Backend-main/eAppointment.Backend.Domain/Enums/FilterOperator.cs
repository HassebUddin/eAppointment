﻿namespace eAppointment.Backend.Domain.Enums
{
    public enum FilterOperator
    {
        And,
        Or
    }
}
