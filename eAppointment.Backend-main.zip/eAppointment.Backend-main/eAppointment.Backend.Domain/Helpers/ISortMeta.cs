﻿namespace eAppointment.Backend.Domain.Helpers
{
    public interface ISortMeta
    {
        string field { set; get; }

        int order { set; get; }
        //
    }
}
