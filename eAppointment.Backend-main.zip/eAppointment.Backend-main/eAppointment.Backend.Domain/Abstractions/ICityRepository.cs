﻿using eAppointment.Backend.Domain.Entities;

namespace eAppointment.Backend.Domain.Abstractions
{
    public interface ICityRepository : IRepository<City>
    {
    }
}
