﻿namespace eAppointment.Backend.Application.Features.Counties.GetAllCountiesByCityId
{
    public sealed record GetAllCountiesByCityIdQueryResponse(
        int id,
        string name);
}
