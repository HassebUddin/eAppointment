﻿namespace eAppointment.Backend.Application.Features.Departments.GetAllDepartments
{
    public sealed record GetAllDepartmentsQueryResponse(
        int id,
        string name);
}
