﻿namespace eAppointment.Backend.Application.Features.Roles.GetAllRoles
{
    public sealed record GetAllRolesQueryResponse(
        int id,
        string? name);
}
