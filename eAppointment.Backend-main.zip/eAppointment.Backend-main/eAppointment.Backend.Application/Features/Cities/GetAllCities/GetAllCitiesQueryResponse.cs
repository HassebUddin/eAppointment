﻿namespace eAppointment.Backend.Application.Features.Cities.GetAllCities
{
    public sealed record GetAllCitiesQueryResponse(
        int id,
        string name);
}
